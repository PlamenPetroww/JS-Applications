import { shwoView } from "./util.js";

const section = document.querySelector('#edi-movie');

export function editPage() {
    shwoView(section)
}