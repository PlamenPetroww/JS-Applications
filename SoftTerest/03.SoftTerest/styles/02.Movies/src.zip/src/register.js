import { shwoView } from "./util.js";

const section = document.querySelector('#form-sign-up');

export function registerPage() {
    shwoView(section)
}