const url = 'http://localhost:3030/jsonstore/messenger';
const messages = document.getElementById('messages');

function attachEvents() {

    document.getElementById('submit').addEventListener('click', loadData);
    document.getElementById('refresh').addEventListener('click', refsreshData);

}

async function loadData() {

    const [author, content] = [document.getElementById('author'), document.getElementById('content')];

    if (author.value !== '' || content.value !== '') {
        //alert('Fields are required');
        await request(url, { author: author.value, content: content.value });
        //messages += `${author.value}: ${content.value}`;
        //event.target.reset()
        author.value = '';
        content.value = '';
    }



}

async function refsreshData() {

    const response = await fetch(url);
    const data = await response.json();

    messages.value = Object.values(data).map(({ author, content }) => `${author}: ${content}`).join('\n')
}

async function request(url, options) {

    if (options) {
        options = {
            method: "post",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(options)
        }
    }

    const response = await fetch(url, options);
    return response.json();

}

attachEvents();